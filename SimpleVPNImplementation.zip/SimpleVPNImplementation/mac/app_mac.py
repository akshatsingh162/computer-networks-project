from flask import Flask, render_template, jsonify, request
import subprocess, psutil, threading, os, socket, signal, time, requests

# ---------- Paths ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# OpenVPN path for macOS (Intel + Apple Silicon)
POSSIBLE_PATHS = [
    "/opt/homebrew/sbin/openvpn",     # Apple Silicon
    "/usr/local/sbin/openvpn"         # Intel
]
OPENVPN_PATH = next((p for p in POSSIBLE_PATHS if os.path.exists(p)), None)

if not OPENVPN_PATH:
    raise FileNotFoundError("OpenVPN not found. Install with: brew install openvpn")

PROFILES_DIR = os.path.join(BASE_DIR, "vpn_profiles")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOGS_DIR, "vpn.log")

app = Flask(__name__)
openvpn_process = None
active_profile = None


# ---------- Utilities ----------
def is_vpn_running():
    # macOS uses utun0, utun1 interfaces when VPN active
    for name, addrs in psutil.net_if_addrs().items():
        if "utun" in name.lower():
            for addr in addrs:
                if addr.family == socket.AF_INET:
                    return True
    return False


def log_output(proc):
    os.makedirs(LOGS_DIR, exist_ok=True)
    with open(LOG_FILE, "w") as f:
        for line in iter(proc.stdout.readline, b''):
            f.write(line.decode(errors="ignore"))
            f.flush()


def get_profiles():
    os.makedirs(PROFILES_DIR, exist_ok=True)
    return sorted([f for f in os.listdir(PROFILES_DIR) if f.endswith(".ovpn")])


def kill_orphan_vpn():
    """Extra safety: kill stray OpenVPN processes"""
    os.system("pkill -f openvpn")


# ---------- Routes ----------
@app.route('/')
def index():
    return render_template("index.html",
        status="Connected" if is_vpn_running() else "Disconnected",
        profiles=get_profiles()
    )


@app.route('/status')
def status():
    return jsonify({
        "status": "Connected" if is_vpn_running() else "Disconnected",
        "active_profile": active_profile
    })


@app.route('/logs')
def logs():
    if os.path.exists(LOG_FILE):
        return jsonify({"logs": open(LOG_FILE).read()[-4000:]})
    return jsonify({"logs": "No logs available."})


@app.route('/connect', methods=['POST'])
def connect():
    global openvpn_process, active_profile

    data = request.get_json() or {}
    profile = data.get("profile")

    if not profile:
        return jsonify({"status": "No profile selected"}), 400

    config = os.path.join(PROFILES_DIR, profile)

    # ✅ Kill existing OpenVPN before switching
    try:
        if openvpn_process and openvpn_process.poll() is None:
            os.killpg(os.getpgid(openvpn_process.pid), signal.SIGTERM)
            time.sleep(1)
    except:
        pass

    kill_orphan_vpn()  # extra cleanup

    # ✅ Start new OpenVPN process
    openvpn_process = subprocess.Popen(
        [OPENVPN_PATH, "--config", config],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        preexec_fn=os.setsid
    )

    active_profile = profile
    threading.Thread(target=log_output, args=(openvpn_process,), daemon=True).start()
    return jsonify({"status": f"Connecting to {profile}..."})


@app.route('/disconnect', methods=['POST'])
def disconnect():
    global openvpn_process, active_profile

    try:
        if openvpn_process and openvpn_process.poll() is None:
            os.killpg(os.getpgid(openvpn_process.pid), signal.SIGTERM)
            time.sleep(1)
    except:
        pass

    kill_orphan_vpn()

    active_profile = None
    openvpn_process = None

    return jsonify({"status": "Disconnected"})


@app.route('/ip')
def get_ip():
    try:
        res = requests.get("https://api.ipify.org?format=json", timeout=5)
        return jsonify({"ip": res.json().get("ip", "Unknown")})
    except:
        return jsonify({"ip": "Error"})


# ---------- Launch ----------
if __name__ == '__main__':
    os.makedirs(LOGS_DIR, exist_ok=True)
    os.makedirs(PROFILES_DIR, exist_ok=True)
    app.run(host="127.0.0.1", port=5000)
