from flask import Flask, render_template, jsonify, request
import subprocess, psutil, threading, os, socket, signal, time, sys, webbrowser
import requests

# ---------- Paths ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OPENVPN_PATH = r"C:\Program Files\OpenVPN\bin\openvpn.exe"
PROFILES_DIR = os.path.join(BASE_DIR, "vpn_profiles")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOGS_DIR, "vpn.log")

app = Flask(__name__)

openvpn_process = None
active_profile = None


# ---------- Utilities ----------
def is_vpn_running():
    """Check if VPN is active by detecting TAP/TUN adapter."""
    try:
        for name, addrs in psutil.net_if_addrs().items():
            if "TAP" in name.upper() or "TUN" in name.upper():
                for addr in addrs:
                    if addr.family == socket.AF_INET and addr.address.startswith("10."):
                        return True
    except Exception:
        pass
    return False


def log_output(proc):
    """Capture and save OpenVPN logs."""
    os.makedirs(LOGS_DIR, exist_ok=True)
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        for line in iter(proc.stdout.readline, b''):
            try:
                f.write(line.decode(errors="ignore"))
            except Exception:
                pass
            f.flush()
        proc.stdout.close()


def get_profiles():
    """Return all .ovpn profiles from vpn_profiles directory."""
    os.makedirs(PROFILES_DIR, exist_ok=True)
    return sorted([f for f in os.listdir(PROFILES_DIR) if f.lower().endswith(".ovpn")])


def kill_existing_openvpn_instances():
    """Force close stray OpenVPN processes."""
    for proc in psutil.process_iter(['name']):
        try:
            if 'openvpn.exe' in (proc.info.get('name') or '').lower():
                proc.kill()
        except Exception:
            pass


# ---------- Routes ----------
@app.route('/')
def index():
    status = "Connected" if is_vpn_running() else "Disconnected"
    profiles = get_profiles()
    return render_template("index.html", status=status, profiles=profiles)


@app.route('/status')
def status():
    status = "Connected" if is_vpn_running() else "Disconnected"
    return jsonify({"status": status, "active_profile": active_profile})


@app.route('/logs')
def logs():
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()[-4000:]
        return jsonify({"logs": content})
    return jsonify({"logs": "No logs available."})


@app.route('/connect', methods=['POST'])
def connect():
    global openvpn_process, active_profile
    data = request.get_json() or {}
    profile = data.get("profile")

    if not profile:
        return jsonify({"status": "No profile selected"}), 400

    config_path = os.path.join(PROFILES_DIR, profile)
    if not os.path.exists(config_path):
        return jsonify({"status": f"Profile '{profile}' not found"}), 404

    if openvpn_process and openvpn_process.poll() is None:
        return jsonify({"status": "Already connected"})

    if not os.path.exists(OPENVPN_PATH):
        return jsonify({"status": f"OpenVPN not found at {OPENVPN_PATH}"}), 500

    try:
        print(f"[+] Connecting with profile: {profile}")
        openvpn_process = subprocess.Popen(
            [OPENVPN_PATH, "--config", config_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )
        active_profile = profile
        threading.Thread(target=log_output, args=(openvpn_process,), daemon=True).start()
        time.sleep(1.5)
        return jsonify({"status": f"Connecting to {profile}..."})
    except Exception as e:
        return jsonify({"status": f"Error starting OpenVPN: {e}"}), 500


@app.route('/disconnect', methods=['POST'])
def disconnect():
    global openvpn_process, active_profile
    try:
        if openvpn_process and openvpn_process.poll() is None:
            try:
                openvpn_process.send_signal(signal.CTRL_BREAK_EVENT)
            except Exception:
                pass
            time.sleep(1.5)
            try:
                openvpn_process.terminate()
            except Exception:
                pass
            try:
                openvpn_process.wait(timeout=5)
            except Exception:
                pass
            openvpn_process = None

        kill_existing_openvpn_instances()
        time.sleep(2)
        active_profile = None
        return jsonify({"status": "Disconnected"})
    except Exception as e:
        return jsonify({"status": f"Error disconnecting: {e}"}), 500

@app.route('/ip')
def get_ip():
    try:
        res = requests.get("https://api.ipify.org?format=json", timeout=5)
        return jsonify({"ip": res.json().get("ip", "Unknown")})
    except:
        return jsonify({"ip": "Error"})

# ---------- Launch ----------
if __name__ == '__main__':
    os.makedirs(LOGS_DIR, exist_ok=True)
    os.makedirs(PROFILES_DIR, exist_ok=True)

    url = "http://127.0.0.1:5000"
    print(f"[+] OpenVPN Web Dashboard started at {url}")

    def open_browser_once():
        time.sleep(1)
        webbrowser.open(url, new=2)

    threading.Thread(target=open_browser_once, daemon=True).start()


    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)

