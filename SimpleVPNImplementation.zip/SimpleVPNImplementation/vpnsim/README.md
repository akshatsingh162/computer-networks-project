# VPN Simulator (vpnsim)

Educational VPN tunnelling simulator with live packet logging and visualization.

What it is
- A Node.js + Express server that simulates encapsulation/decapsulation of packets.
- A front-end webpage that visualizes packets moving through a tunnel and shows logs.

Quick start (Windows, cmd.exe)

1. Open a terminal in `d:\vpnsim`

2. Install dependencies:

   npm install

3. Start the server:

   npm start

4. Open http://localhost:3000 in your browser.

Notes
- This is for educational/visualization purposes only. The network behavior is simulated and not secure.
- You can control the simulator from the page or via the HTTP API (`/api/start`, `/api/stop`, `/api/send`).

Next steps (ideas)
- Add PCAP export
- Add more realistic protocol fields and packet inspectors
- Persist logs to disk and add filtering/search UI

License: MIT
