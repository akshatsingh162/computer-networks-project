const socket = io();

// UI Elements
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const rateInput = document.getElementById('rateInput');
const logList = document.getElementById('logList');
const pipe = document.getElementById('pipe');
const sendForm = document.getElementById('sendForm');
const clearLogsBtn = document.getElementById('clearLogs');
const inspector = document.getElementById('inspector');
const inspectorContent = document.getElementById('inspectorContent');
const closeInspector = document.getElementById('closeInspector');
const vpnStatus = document.getElementById('vpnStatus');

let running = false;

// Fake encryption/decryption
function encrypt(data) {
  return btoa(data.split('').reverse().join(''));
}

function decrypt(data) {
  return atob(data).split('').reverse().join('');
}

// Random IP generators
function randomPrivateIP() {
  return `10.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}`;
}
function randomPublicIP() {
  return `${Math.floor(Math.random()*223)}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}`;
}

// Logging utility
function addLog(entry) {
  const el = document.createElement('div');
  el.className = 'log-item';
  el.innerHTML = `<strong>${entry.type}</strong> — ${entry.desc}<br><small>${entry.time}</small>`;
  el.addEventListener('click', () => showInspector(entry));
  logList.prepend(el);
  while (logList.children.length > 400) logList.removeChild(logList.lastChild);
}

function showInspector(obj) {
  inspectorContent.textContent = JSON.stringify(obj, null, 2);
  inspector.classList.remove('hidden');
}

closeInspector.addEventListener('click', () => inspector.classList.add('hidden'));
clearLogsBtn.addEventListener('click', () => { logList.innerHTML = ''; });

// Simulate packet animation
function animatePacket(p) {
  const bubble = document.createElement('div');
  bubble.className = 'packet';
  bubble.textContent = p.kind === 'encapsulated' ? '🔒' : '📦';
  pipe.appendChild(bubble);

  const distance = p.direction === 'toRemote' ? pipe.clientWidth - 80 : 0;
  requestAnimationFrame(() => {
    bubble.style.transform = `translateY(-50%) translateX(${distance}px)`;
  });

  setTimeout(() => bubble.remove(), 2500);
}

// VPN connection simulation
function setVPNState(state) {
  switch (state) {
    case 'connecting':
      vpnStatus.textContent = '🟡 Connecting...';
      break;
    case 'connected':
      vpnStatus.textContent = '🟢 Connected (Secure Tunnel Active)';
      break;
    case 'disconnecting':
      vpnStatus.textContent = '🟠 Disconnecting...';
      break;
    case 'disconnected':
      vpnStatus.textContent = '🔴 Disconnected';
      break;
  }
}

startBtn.addEventListener('click', () => {
  running = true;
  startBtn.disabled = true;
  stopBtn.disabled = false;
  setVPNState('connecting');
  setTimeout(() => {
    setVPNState('connected');
    addLog({ type: 'INFO', desc: 'VPN tunnel established between 192.168.1.10 → 20.55.120.8', time: new Date().toLocaleTimeString() });
  }, 1000);
});

stopBtn.addEventListener('click', () => {
  running = false;
  startBtn.disabled = false;
  stopBtn.disabled = true;
  setVPNState('disconnecting');
  setTimeout(() => setVPNState('disconnected'), 800);
  addLog({ type: 'INFO', desc: 'VPN tunnel terminated', time: new Date().toLocaleTimeString() });
});

// Simulated packet sending
sendForm.addEventListener('submit', (ev) => {
  ev.preventDefault();
  if (!running) return alert('VPN not connected!');

  const form = new FormData(sendForm);
  const src = form.get('src') || randomPrivateIP();
  const dst = form.get('dst') || randomPrivateIP();
  const size = parseInt(form.get('size')) || 80;
  const direction = Math.random() > 0.5 ? 'toRemote' : 'toLocal';

  // Inner (private) packet
  const innerPacket = {
    src, dst, size,
    data: "This is private network data.",
    timestamp: new Date().toISOString()
  };

  // Step 1: Encapsulate with outer (public) IPs
  const outerPacket = {
    kind: 'encapsulated',
    direction,
    outer: {
      src: direction === 'toRemote' ? '192.168.1.10' : '20.55.120.8',
      dst: direction === 'toRemote' ? '20.55.120.8' : '192.168.1.10'
    },
    inner: innerPacket
  };

  addLog({
    type: 'ENCAPSULATION',
    desc: `Inner ${src}→${dst} wrapped inside outer ${outerPacket.outer.src}→${outerPacket.outer.dst}`,
    time: new Date().toLocaleTimeString(),
    packet: outerPacket
  });

  animatePacket(outerPacket);

  // Step 2: Encrypt
  const encrypted = encrypt(JSON.stringify(innerPacket));

  addLog({
    type: 'ENCRYPTION',
    desc: `Encrypted payload (${encrypted.substring(0, 20)}...) sent securely`,
    time: new Date().toLocaleTimeString()
  });

  // Step 3: Transmission & Decapsulation
  setTimeout(() => {
    animatePacket({ kind: 'decapsulated', direction: direction === 'toRemote' ? 'toLocal' : 'toRemote' });
    const decrypted = decrypt(encrypted);

    addLog({
      type: 'DECAPSULATION',
      desc: `Packet received and decrypted: ${decrypted.substring(0, 40)}...`,
      time: new Date().toLocaleTimeString()
    });
  }, parseInt(rateInput.value));
});
