const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const bodyParser = require('body-parser');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(bodyParser.json());
app.use(express.static(__dirname + '/public'));

// In-memory logs (simple educational purpose)
const logs = [];
let nextPacketId = 1;

function log(entry) {
  const e = { id: logs.length + 1, ts: new Date().toISOString(), ...entry };
  logs.push(e);
  // keep last 200 logs
  if (logs.length > 200) logs.shift();
  io.emit('log', e);
}

// Packet simulation helpers
function makePayload(size = 32) {
  // random hex payload
  const bytes = [];
  for (let i = 0; i < size; i++) bytes.push(Math.floor(Math.random() * 256));
  return Buffer.from(bytes).toString('hex');
}

function makePacket(src = '10.0.0.1', dst = '10.0.0.2', proto = 'TCP', size = 64) {
  return {
    id: nextPacketId++,
    src,
    dst,
    proto,
    size,
    payload: makePayload(Math.max(1, Math.min(256, Math.floor(size / 2)))),
    ts: new Date().toISOString(),
  };
}

function encapsulate(packet, tunnelId = 'tun0') {
  // Very simple encapsulation: add outer header metadata
  return {
    outer: {
      src: '192.0.2.1',
      dst: '203.0.113.1',
      proto: 'GRE',
      tunnel: tunnelId,
    },
    inner: packet,
    ts: new Date().toISOString(),
  };
}

// Simulation control
let simInterval = null;
let simRunning = false;
let simRateMs = 1000; // packets per second interval

function startSim(rateMs = 1000) {
  if (simRunning) return;
  simRateMs = rateMs;
  simInterval = setInterval(() => {
    const pkt = makePacket();
    const enc = encapsulate(pkt);
    log({ type: 'encapsulated', packet: pkt, encapsulated: enc });
    io.emit('packet', { kind: 'encapsulated', data: enc });
    // after small delay, decapsulate (simulate arrival)
    setTimeout(() => {
      const dec = { ...pkt, received: true, ts: new Date().toISOString() };
      log({ type: 'decapsulated', packet: dec });
      io.emit('packet', { kind: 'decapsulated', data: dec });
    }, Math.floor(Math.random() * 300) + 50);
  }, simRateMs);
  simRunning = true;
  io.emit('sim-status', { running: true, rateMs: simRateMs });
  log({ type: 'sim-start', rateMs: simRateMs });
}

function stopSim() {
  if (!simRunning) return;
  clearInterval(simInterval);
  simInterval = null;
  simRunning = false;
  io.emit('sim-status', { running: false });
  log({ type: 'sim-stop' });
}

// HTTP control
app.get('/api/logs', (req, res) => {
  const n = Math.min(200, parseInt(req.query.n || '100', 10));
  res.json(logs.slice(-n));
});

app.post('/api/start', (req, res) => {
  const rateMs = parseInt(req.body.rateMs, 10) || 1000;
  startSim(rateMs);
  res.json({ ok: true, running: true, rateMs });
});

app.post('/api/stop', (req, res) => {
  stopSim();
  res.json({ ok: true, running: false });
});

app.post('/api/send', (req, res) => {
  // send a single manual packet through the tunnel
  const body = req.body || {};
  const pkt = makePacket(body.src || '10.0.0.100', body.dst || '10.0.0.200', body.proto || 'UDP', body.size || 80);
  const enc = encapsulate(pkt, body.tunnel || 'tun0');
  log({ type: 'manual-encapsulated', packet: pkt, encapsulated: enc });
  io.emit('packet', { kind: 'encapsulated', data: enc });
  setTimeout(() => {
    const dec = { ...pkt, received: true, ts: new Date().toISOString() };
    log({ type: 'manual-decapsulated', packet: dec });
    io.emit('packet', { kind: 'decapsulated', data: dec });
  }, 150);
  res.json({ ok: true, packet: pkt, encapsulated: enc });
});

// Socket.IO for live updates
io.on('connection', (socket) => {
  socket.emit('sim-status', { running: simRunning, rateMs: simRateMs });
  socket.emit('logs-init', logs.slice(-100));
  socket.on('start', (data) => {
    startSim(data && data.rateMs ? data.rateMs : simRateMs);
  });
  socket.on('stop', () => {
    stopSim();
  });
  socket.on('send', (payload) => {
    const pkt = makePacket(payload && payload.src, payload && payload.dst, payload && payload.proto, payload && payload.size);
    const enc = encapsulate(pkt, payload && payload.tunnel);
    log({ type: 'manual-encapsulated', packet: pkt, encapsulated: enc });
    socket.emit('packet', { kind: 'encapsulated', data: enc });
    setTimeout(() => {
      const dec = { ...pkt, received: true, ts: new Date().toISOString() };
      log({ type: 'manual-decapsulated', packet: dec });
      socket.emit('packet', { kind: 'decapsulated', data: dec });
    }, 150);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`VPN Simulator running on http://localhost:${PORT}`);
});
