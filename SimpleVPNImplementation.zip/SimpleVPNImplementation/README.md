📌 Overview

This project is a Web-based OpenVPN controller built using Flask.
It provides a clean dashboard to view, select, and manage .ovpn VPN profiles directly from the browser, without manually running console commands.

The backend launches and monitors the OpenVPN client process, parses real-time logs, detects VPN connection status, and provides interactive controls for connecting and disconnecting.

🎯 Key Features

🖥️ Web UI for OpenVPN

📂 Auto-detect .ovpn profiles in vpn_profiles/

🔐 One-click connect/disconnect

📡 Live VPN status indicator (Connected / Disconnected)

🧾 Real-time log viewer

🕵️ Auto-detect TAP/TUN network interfaces

🔧 Graceful and force disconnect handling

🧹 Cleanup of stale OpenVPN processes

🏗️ Architecture
Component	Purpose
Flask Backend	Serves UI & handles VPN control logic
Subprocess Module	Launches OpenVPN client in background
Psutil	Detects TAP/TUN adapters & kills stray processes
Threading	Asynchronous log streaming
Web UI	Displays profiles, logs & status
⚙️ How It Works
1️⃣ Profile Detection

All .ovpn files located in the vpn_profiles folder are automatically listed in the UI.

2️⃣ Connection

When the user selects a profile, the backend:

Starts openvpn.exe with the selected config

Captures stdout for live logs

Tracks the process handle to disconnect later

3️⃣ Log Streaming

Output from the OpenVPN process is written to logs/vpn.log in real-time and displayed in the dashboard.

4️⃣ VPN Status Checking

The server inspects network interfaces to detect an active VPN session by checking:

Presence of TAP/TUN adapter

IP range (e.g. 10.x.x.x)

5️⃣ Disconnection

The app attempts a graceful shutdown by sending a CTRL_BREAK_EVENT.
If needed, it force-terminates the OpenVPN process and clears any leftover processes.


 To run on windows just run "run.bat" as an administrator
Note:
To Run on Mac, Go to the mac folder and inside the folder open the terminal, run the command sudo python3 app_mac.py and open the link http://127.0.0.1:5000 in the browser