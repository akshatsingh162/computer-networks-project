import ipaddress
import random

interfaces = {
    "LAN": "192.168.1.0/24",
    "WAN": "10.0.0.0/24"
}

connection_table = []


threat_tracker = {} 


def ip_match(rule_ip, pkt_ip):
    """Match IP address with wildcard support
    Supports:
    - "*" matches any IP
    - "192.168.1.*" matches 192.168.1.0-255
    - "192.*.*.*" matches 192.x.x.x
    - CIDR notation: "192.168.1.0/24"
    - Exact match: "192.168.1.1"
    """
    if rule_ip == "*" or not rule_ip:
        return True
    
   
    if "*" in rule_ip:
       
        rule_parts = rule_ip.split(".")
        pkt_parts = pkt_ip.split(".")
        
        if len(rule_parts) != 4 or len(pkt_parts) != 4:
            
            prefix = rule_ip.split("*")[0]
            return pkt_ip.startswith(prefix) if prefix else True
        
       
        for i in range(4):
            if rule_parts[i] == "*":
                continue  
            if rule_parts[i] != pkt_parts[i]:
                return False
        return True
    
    
    try:
        net = ipaddress.ip_network(rule_ip, strict=False)
        return ipaddress.ip_address(pkt_ip) in net
    except ValueError:
        pass
    
    
    return pkt_ip == rule_ip


def match_rule(rule, pkt):
    if not ip_match(rule["source"], pkt["source"]):
        return False
    if not ip_match(rule["destination"], pkt["destination"]):
        return False
    
    rule_proto = (rule.get("protocol") or "").strip()
    pkt_proto = (pkt.get("protocol") or "").strip()
    if rule_proto and rule_proto != "*":  
        if not pkt_proto or rule_proto.lower() != pkt_proto.lower():
            return False
    
    rule_port = rule.get("port")
    pkt_port = pkt.get("port")
    
    if rule_port is not None:
        
        if isinstance(rule_port, str) and rule_port.strip() == "*":
            return True  
        
        
        if pkt_port is not None:
            if isinstance(pkt_port, str) and pkt_port.strip() == "*":
                return True  
        
      
        try:
            rule_port_num = int(rule_port)
            if pkt_port is None:
                return False 
            if isinstance(pkt_port, str):
                pkt_port_num = int(pkt_port)
            else:
                pkt_port_num = pkt_port
            
            if rule_port_num != pkt_port_num:
                return False
        except (ValueError, TypeError):
            
            if str(rule_port) != str(pkt_port):
                return False
    return True


def update_connection_table(pkt, result):
    existing = next((c for c in connection_table
                     if c["source"] == pkt["source"]
                     and c["destination"] == pkt["destination"]), None)

    if not existing:
        state = "ESTABLISHED" if "ALLOWED" in result else "BLOCKED"
        connection_table.append({
            "source": pkt["source"],
            "destination": pkt["destination"],
            "protocol": pkt.get("protocol", ""),
            "state": state
        })
    else:
        existing["state"] = "ESTABLISHED" if "ALLOWED" in result else "BLOCKED"


def simulate_packet_advanced(pkt, rules):
    pkt_proto = pkt.get('protocol', '') or 'ANY'
    pkt_port = pkt.get('port')
    pkt_port_str = str(pkt_port) if pkt_port is not None else 'ANY'
    steps = [f"Incoming packet: {pkt['source']} → {pkt['destination']} ({pkt_proto}, Port {pkt_port_str})"]

    for i, rule in enumerate(rules, start=1):
        rule_proto = rule.get('protocol', '') or 'ANY'
        rule_port = rule.get('port')
        rule_port_str = str(rule_port) if rule_port is not None else 'ANY'
        steps.append(f"Checking rule {i}: {rule['source']} → {rule['destination']} ({rule_proto}, Port {rule_port_str}) [{rule['action'].upper()}]")
        if match_rule(rule, pkt):
            action = rule["action"].upper()
            result = f"Packet {action}ED: matched rule #{i}"
            steps.append(f"Rule matched → {action}")
            update_connection_table(pkt, result)
            
           
            if action == "BLOCK":
                source_ip = pkt['source']
                threat_tracker[source_ip] = threat_tracker.get(source_ip, 0) + 1
            
            return result, action, steps

    result = f"Packet ALLOWED: no matching rule"
    steps.append("No rule matched → ALLOW by default")
    update_connection_table(pkt, result)
    return result, "ALLOW", steps


def get_threat_ips():
    """Return list of IPs with 3+ blocked packets"""
    return [ip for ip, count in threat_tracker.items() if count >= 3]
