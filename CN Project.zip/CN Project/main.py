from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
import random
from features import simulate_packet_advanced, interfaces, connection_table, get_threat_ips, threat_tracker

app = FastAPI()
templates = Jinja2Templates(directory="templates")

rules = []


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    threat_ips = get_threat_ips()
    edit_index = request.query_params.get("edit_index")
    editing_rule = None
    if edit_index and edit_index.isdigit():
        index = int(edit_index)
        if 0 <= index < len(rules):
            editing_rule = rules[index]
    
    return templates.TemplateResponse("index.html", {
        "request": request,
        "rules": rules,
        "connections": connection_table,
        "result": None,
        "steps": None,
        "packet_protocol": None,
        "threat_ips": threat_ips,
        "rule_error": None,
        "sim_error": None,
        "editing_rule": editing_rule,
        "edit_index": edit_index
    })


@app.post("/add_rule")
async def add_rule(
    request: Request,
    source: str = Form(""),
    destination: str = Form(""),
    protocol: str = Form(""),
    port: str = Form(""),
    action: str = Form("")
):
    if not source or not destination or not action:
        threat_ips = get_threat_ips()
        return templates.TemplateResponse("index.html", {
            "request": request,
            "rules": rules,
            "connections": connection_table,
            "result": None,
            "steps": None,
            "packet_protocol": None,
            "threat_ips": threat_ips,
            "rule_error": "Please provide Source, Destination, and Action.",
            "sim_error": None,
            "editing_rule": None,
            "edit_index": None
        })

    port_value = None
    if port:
        port = port.strip()
        
        if port == "*":
            port_value = "*"
        else:
            try:
                port_value = int(port)
                if port_value < 0 or port_value > 65535:
                    raise ValueError
            except ValueError:
                threat_ips = get_threat_ips()
                return templates.TemplateResponse("index.html", {
                    "request": request,
                    "rules": rules,
                    "connections": connection_table,
                    "result": None,
                    "steps": None,
                    "packet_protocol": None,
                    "threat_ips": threat_ips,
                    "rule_error": "Invalid port number. Must be 0–65535 or *.",
                    "sim_error": None,
                    "editing_rule": None,
                    "edit_index": None
                })

    rule_index = request.query_params.get("edit_index")
    
    new_rule = {
        "source": source,
        "destination": destination,
        "protocol": protocol,
        "port": port_value,
        "action": action
    }
    
   
    if rule_index and rule_index.isdigit():
        index = int(rule_index)
        if 0 <= index < len(rules):
            rules[index] = new_rule
    else:
        rules.append(new_rule)
    
    return RedirectResponse("/", status_code=303)


@app.post("/simulate")
async def simulate_ui(
    request: Request,
    source: str = Form(""),
    destination: str = Form(""),
    protocol: str = Form(""),
    port: str = Form(""),
    interface: str = Form("LAN")
):
    if not source or not destination:
        threat_ips = get_threat_ips()
        return templates.TemplateResponse("index.html", {
            "request": request,
            "rules": rules,
            "connections": connection_table,
            "result": None,
            "steps": None,
            "packet_protocol": None,
            "threat_ips": threat_ips,
            "rule_error": None,
            "sim_error": "Please provide Source and Destination IPs.",
            "editing_rule": None,
            "edit_index": None
        })

    port_value = None
    if port:
        port = port.strip()
        
        if port == "*":
            port_value = "*"
        else:
            try:
                port_value = int(port)
                if port_value < 0 or port_value > 65535:
                    raise ValueError
            except ValueError:
                threat_ips = get_threat_ips()
                return templates.TemplateResponse("index.html", {
                    "request": request,
                    "rules": rules,
                    "connections": connection_table,
                    "result": None,
                    "steps": None,
                    "packet_protocol": None,
                    "threat_ips": threat_ips,
                    "rule_error": None,
                    "sim_error": "Invalid port number. Must be 0–65535 or *.",
                    "editing_rule": None,
                    "edit_index": None
                })

    pkt = {"source": source, "destination": destination, "protocol": protocol, "port": port_value, "interface": interface}
    result, action, steps = simulate_packet_advanced(pkt, rules)
    threat_ips = get_threat_ips()

    return templates.TemplateResponse("index.html", {
        "request": request,
        "rules": rules,
        "connections": connection_table,
        "result": result,
        "steps": steps,
        "packet_protocol": protocol.upper() if protocol else "TCP",
        "threat_ips": threat_ips,
        "rule_error": None,
        "sim_error": None,
        "editing_rule": None,
        "edit_index": None
    })


@app.post("/simulate_random")
async def simulate_random_ui(request: Request):
    src = f"192.168.1.{random.randint(1, 254)}"
    dst = f"10.0.0.{random.randint(1, 254)}"
    proto = random.choice(["TCP", "UDP", "ICMP"])
    port = random.choice([22, 53, 80, 443])
    pkt = {"source": src, "destination": dst, "protocol": proto, "port": port}
    result, action, steps = simulate_packet_advanced(pkt, rules)
    threat_ips = get_threat_ips()
    return templates.TemplateResponse("index.html", {
        "request": request,
        "rules": rules,
        "connections": connection_table,
        "result": result,
        "steps": steps,
        "packet_protocol": proto,
        "threat_ips": threat_ips,
        "rule_error": None,
        "sim_error": None,
        "editing_rule": None,
        "edit_index": None
    })


@app.post("/delete_rule")
async def delete_rule(request: Request, rule_index: str = Form(...)):
    try:
        index = int(rule_index)
        if 0 <= index < len(rules):
            rules.pop(index)
    except (ValueError, IndexError):
        pass  
    return RedirectResponse("/", status_code=303)


@app.post("/clear")
async def clear_rules(request: Request):
    rules.clear()
    connection_table.clear()
    threat_tracker.clear()  
    return RedirectResponse("/", status_code=303)


if __name__ == "__main__":
    import uvicorn, webbrowser
    webbrowser.open("http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000)
