# Firewall Simulator

A **web-based Firewall Simulator** application to create, manage, and simulate firewall rules for packet filtering.  
It allows users to define firewall rules with IP address patterns, protocols, and ports; simulate packet traversal through layers; and view whether packets are allowed or blocked according to the rules.

---

## Features

- Add, Edit, and Delete firewall rules specifying:
  - Source IP
  - Destination IP
  - Protocol (TCP, UDP, ICMP, or any)
  - Port
  - Action (allow or block)
- Supports **wildcards** in IP addresses and ports for flexible rule matching.
- **Simulate packets** passing through the firewall with detailed, step-by-step rule evaluation.
- **Visualize packet traversal** through OSI/TCP-IP layers with an animated UI.
- **Maintain a connection table** showing stateful connections and track potentially malicious IP addresses (those with repeated blocked packets).
- **Clear all firewall rules and connection history.**
- **Random packet simulation** for testing firewall rules.

---

## Technologies Used

### Backend
- **FastAPI** for server-side logic and API endpoints.

### Frontend
- **HTML** and **Tailwind CSS** for styling.  
- **JavaScript** for interactivity and animations.

### Templating
- **Jinja2** templates for rendering dynamic content.

### Core Logic
- **Python modules** for:
  - Firewall logic  
  - IP matching  
  - Rule evaluation  
  - Connection tracking  
  - Threat detection

---

## ⚙️ Installation and Running

### Requirements
- Python **3.7 or higher**

### 1️⃣ Set Up Virtual Environment (Recommended)

Navigate to your project directory in a terminal.

```bash
python -m venv venv
```

Activate the environment:

#### On Windows:
```bash
venv\Scripts\activate.bat
```

#### On macOS/Linux:
```bash
source venv/bin/activate
```

### Install Dependencies

```bash
pip install fastapi uvicorn jinja2
```

### Run the Application

```bash
python main.py
```

The app will open automatically in your browser at:  
👉 [http://127.0.0.1:8000](http://127.0.0.1:8000)

---

## File Structure

```
Firewall-Simulator/
│
├── main.py          # FastAPI server handling routes for rules, packets, and UI
├── features.py      # Core firewall logic (rule matching, tracking, simulation)
├── templates/
│   └── index.html   # Frontend template with Tailwind and JS animations
└── static/          # (Optional) CSS/JS files if not inline
```

---

## Usage

1. Add firewall rules by specifying:
   - Source/Destination IPs (supports wildcards)
   - Protocol
   - Port
   - Action (allow/block)

2. Use the **packet simulation** form to input packet details and see whether it’s allowed or blocked.

3. **Visualize packet flow** through network layers (animated view).

4. Inspect:
   - Current firewall rules  
   - Connection table

5. Use **“Simulate Random Packet”** for quick testing.

6. **Clear all rules and connections** when needed.

---

## Additional Information

- IPs can include wildcards like `192.168.1.*` to match ranges.  
- Ports can be specific numbers or wildcards (`*` for any).  
- The simulator demonstrates **TCP/IP Layer encapsulation** visually.  
- Repeated blocked packets from the same IP are **tracked and flagged as threats**.

---
